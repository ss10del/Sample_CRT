// popup.js
document.addEventListener('DOMContentLoaded', () => {
  const tokenInput = document.getElementById('githubToken');
  const modelSelect = document.getElementById('model');
  const autoDetectBtn = document.getElementById('autoDetect');
  const showImpactBtn = document.getElementById('showImpact');
  const syncScrollBtn = document.getElementById('syncScroll');
  const saveBtn = document.getElementById('saveBtn');
  const statusMsg = document.getElementById('statusMsg');
  const toggleKeyBtn = document.getElementById('toggleKey');

  chrome.storage.sync.get(
    ['githubToken', 'model', 'autoDetect', 'showImpact', 'syncScroll'],
    (data) => {
      if (data.githubToken) tokenInput.value = data.githubToken;
      if (data.model) modelSelect.value = data.model;
      setToggle(autoDetectBtn, data.autoDetect !== false);
      setToggle(showImpactBtn, data.showImpact !== false);
      setToggle(syncScrollBtn, data.syncScroll !== false);
    }
  );

  toggleKeyBtn.addEventListener('click', () => {
    const isPass = tokenInput.type === 'password';
    tokenInput.type = isPass ? 'text' : 'password';
    toggleKeyBtn.textContent = isPass ? '🙈' : '👁';
  });

  [autoDetectBtn, showImpactBtn, syncScrollBtn].forEach(btn => {
    btn.addEventListener('click', () => btn.classList.toggle('on'));
  });

  saveBtn.addEventListener('click', () => {
    const githubToken = tokenInput.value.trim();
    const model = modelSelect.value;

    if (!githubToken) {
      showStatus('Please enter your GitHub token.', 'error');
      tokenInput.focus();
      return;
    }

    if (!githubToken.startsWith('ghp_') && !githubToken.startsWith('github_pat_') && !githubToken.startsWith('gho_')) {
      showStatus('Token should start with ghp_, github_pat_, or gho_', 'error');
      return;
    }

    saveBtn.textContent = 'Saving...';
    saveBtn.disabled = true;

    chrome.storage.sync.set({
      githubToken, model,
      autoDetect: autoDetectBtn.classList.contains('on'),
      showImpact: showImpactBtn.classList.contains('on'),
      syncScroll: syncScrollBtn.classList.contains('on')
    }, () => {
      saveBtn.textContent = 'Save Settings';
      saveBtn.disabled = false;
      showStatus('✓ Settings saved!', 'success');
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs[0]) chrome.tabs.sendMessage(tabs[0].id, { type: 'SETTINGS_UPDATED' }).catch(() => {});
      });
    });
  });

  function setToggle(btn, on) { if (on) btn.classList.add('on'); else btn.classList.remove('on'); }

  function showStatus(msg, type) {
    statusMsg.textContent = msg;
    statusMsg.className = `status-msg ${type}`;
    setTimeout(() => { statusMsg.className = 'status-msg'; }, 3500);
  }
});
