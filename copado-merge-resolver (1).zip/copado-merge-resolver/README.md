# Copado AI Merge Resolver — Browser Extension

> AI-powered merge conflict resolution overlay for Copado DevOps with per-line impact analysis, inline editing, and one-click deployment acceptance.

---

## Features

- **3-Panel Conflict View** — BASE | INCOMING | AI RESOLVED side-by-side
- **AI-Powered Resolution** — Uses Claude AI to intelligently resolve all conflict blocks
- **Per-Line Impact Analysis** — Hover any changed line for a 2-3 sentence AI explanation of what changed and why
- **Inline Editing** — Toggle edit mode to manually tweak the AI suggestion
- **Confidence Indicators** — High/Medium/Low confidence markers on each changed line
- **Deployment Summary** — Risk level, conflict count, and deployment notes
- **One-Click Accept** — Saves resolution and writes back to Copado's editor
- **Draggable Panel** — Position the overlay anywhere on screen
- **SPA-Aware** — Detects Copado navigation and re-scans on page changes

---

## Installation

### Chrome / Edge / Brave (Manifest V3)

1. Open `chrome://extensions` (or `edge://extensions`)
2. Enable **Developer Mode** (top-right toggle)
3. Click **Load unpacked**
4. Select the `copado-merge-resolver` folder
5. The extension icon will appear in your toolbar

### Firefox (Manifest V3 compatible)

1. Open `about:debugging#/runtime/this-firefox`
2. Click **Load Temporary Add-on**
3. Select `manifest.json` inside the folder
4. Note: For permanent installation, the extension must be signed via AMO

---

## Configuration

1. Click the extension icon in your toolbar
2. Enter your **Anthropic API Key** (get one at [console.anthropic.com](https://console.anthropic.com))
3. Select your preferred model (Claude Sonnet 4 recommended)
4. Click **Save Settings**

### Getting an API Key
- Sign up at https://console.anthropic.com
- Go to API Keys → Create Key
- Your key will start with `sk-ant-`

---

## Usage

1. Navigate to a Copado User Story with merge conflicts
2. The extension auto-detects conflict panels and shows the overlay
3. The 3-panel view shows: **BASE branch** | **INCOMING changes** | **AI resolution**
4. Click **"Resolve with AI"** to generate the resolution
5. Hover any highlighted line to see the **impact analysis**
6. Use **"Edit"** to manually adjust the AI suggestion
7. Click **"Accept"** to save and apply the resolved code to Copado

---

## How It Works

### Conflict Detection
The extension uses `MutationObserver` to watch for Copado's conflict UI components:
- Scans for `<<<<<<< / ======= / >>>>>>>` conflict markers in the DOM
- Watches Salesforce Lightning Web Components for merge-related panels
- Re-scans on SPA navigation

### AI Resolution
Sends the base code, incoming code, and parsed conflict blocks to the Anthropic API. The AI returns:
- **Fully resolved code** with no conflict markers
- **Line-by-line analysis** with change type, confidence, source branch, and impact
- **Deployment summary** with risk level and notes

### Writing Back to Copado
The extension attempts to write the resolved code back to Copado's editor in this priority order:
1. CodeMirror instance (`.CodeMirror`)
2. ACE editor (`.ace_editor`)
3. Native textarea with React/LWC event dispatching
4. Clipboard fallback with copy button

---

## Supported Copado Pages

- User Story merge conflict resolution pages
- Copado Deployment Manager conflict views
- Any Salesforce org page with conflict markers

**Domains monitored:**
- `*.salesforce.com`
- `*.force.com`
- `*.copado.com`
- `*.lightning.force.com`

---

## Privacy

- Your code is sent to the Anthropic API for resolution. Review [Anthropic's privacy policy](https://www.anthropic.com/privacy).
- API keys are stored locally in `chrome.storage.sync` (synced across your Chrome profile).
- No data is sent to any other third party.

---

## Troubleshooting

**Panel doesn't appear?**
- Try clicking "Re-scan" in the panel, or refresh the page
- Make sure you're on a Copado/Salesforce merge conflict page

**"No API key configured" error?**
- Open the extension popup and enter your Anthropic API key

**Resolution failed?**
- Check your API key is valid and has credits
- Try switching to a different model in settings

**Code not writing back to Copado?**
- Use the clipboard fallback (copy button appears automatically)
- Manually paste into Copado's editor

---

## File Structure

```
copado-merge-resolver/
├── manifest.json      # Extension manifest (MV3)
├── background.js      # Service worker — API calls & storage
├── content.js         # Page injection & conflict detection
├── content.css        # Panel styles
├── popup.html         # Settings popup
├── popup.js           # Settings logic
├── README.md          # This file
└── icons/
    ├── icon16.png
    ├── icon48.png
    └── icon128.png
```

---

## Version History

**v1.0.0** — Initial release
- 3-panel diff view with AI resolution
- Per-line impact analysis with hover tooltips
- Inline editing mode
- CodeMirror/ACE/LWC write-back support
- Draggable panel with minimize/close
