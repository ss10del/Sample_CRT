// background.js — Service Worker for Copado AI Merge Resolver
// Uses GitHub Models API (GitHub Copilot) — https://models.inference.ai.azure.com

chrome.runtime.onInstalled.addListener(() => {
  console.log('[CopadoAI] Extension installed.');
  chrome.storage.sync.set({ aiProvider: 'github', model: 'gpt-4o' });
});

// Handle messages from content script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'RESOLVE_CONFLICT') {
    handleResolveConflict(message.payload).then(sendResponse).catch(err => {
      sendResponse({ error: err.message });
    });
    return true; // keep channel open for async
  }

  if (message.type === 'GET_SETTINGS') {
    chrome.storage.sync.get(['apiKey', 'aiProvider', 'model'], (result) => {
      sendResponse(result);
    });
    return true;
  }

  if (message.type === 'SAVE_RESOLUTION') {
    saveResolution(message.payload).then(sendResponse).catch(err => {
      sendResponse({ error: err.message });
    });
    return true;
  }
});

async function handleResolveConflict({ baseCode, incomingCode, fileName, conflictBlocks }) {
  const settings = await new Promise(resolve =>
    chrome.storage.sync.get(['githubToken', 'model'], resolve)
  );

  const token = settings.githubToken;
  if (!token) throw new Error('No GitHub token configured. Open the extension popup to add your token.');

  const model = settings.model || 'gpt-4o';
  const prompt = buildPrompt(baseCode, incomingCode, fileName, conflictBlocks);

  // GitHub Models API — OpenAI-compatible endpoint powered by GitHub Copilot
  const response = await fetch('https://models.inference.ai.azure.com/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`
    },
    body: JSON.stringify({
      model,
      max_tokens: 4096,
      temperature: 0.2,
      response_format: { type: 'json_object' },
      messages: [
        {
          role: 'system',
          content: `You are an expert code merge conflict resolver embedded in a Copado DevOps platform.
Your job is to intelligently resolve merge conflicts by understanding the intent of both branches.
Always respond with a valid JSON object only. No markdown fences, no extra text.`
        },
        { role: 'user', content: prompt }
      ]
    })
  });

  if (!response.ok) {
    const err = await response.text();
    if (response.status === 401) throw new Error('GitHub token invalid or expired. Check your token in extension settings.');
    if (response.status === 403) throw new Error('GitHub token lacks permission. Make sure it has "models:read" scope.');
    if (response.status === 429) throw new Error('Rate limit hit. Wait a moment and try again.');
    throw new Error(`GitHub Copilot API error ${response.status}: ${err}`);
  }

  const data = await response.json();
  const raw = data.choices?.[0]?.message?.content || '';

  try {
    const clean = raw.replace(/```json|```/g, '').trim();
    return JSON.parse(clean);
  } catch {
    throw new Error('AI returned malformed JSON. Try again.');
  }
}

function buildPrompt(baseCode, incomingCode, fileName, conflictBlocks) {
  return `You are resolving merge conflicts in a Salesforce/Copado deployment for file: "${fileName || 'unknown'}".

## BASE BRANCH (Current):
\`\`\`
${baseCode}
\`\`\`

## INCOMING BRANCH (Changes):
\`\`\`
${incomingCode}
\`\`\`

## CONFLICT BLOCKS DETECTED:
${JSON.stringify(conflictBlocks, null, 2)}

Resolve all conflicts intelligently. For EACH line in the resolved code, provide an impact analysis.

Respond ONLY with this JSON structure (no markdown fences):
{
  "resolvedCode": "full resolved file content here",
  "summary": "2-3 sentence overall summary of what was resolved and why",
  "lineAnalysis": [
    {
      "lineNumber": 1,
      "code": "exact line content",
      "changeType": "added|removed|modified|unchanged|conflict-resolved",
      "impact": "2-3 sentence analysis of what this line does and why this resolution was chosen",
      "confidence": "high|medium|low",
      "source": "base|incoming|merged|ai-generated"
    }
  ],
  "conflictsResolved": 2,
  "riskLevel": "low|medium|high",
  "deploymentNotes": "any important notes for deployment"
}`;
}

async function saveResolution({ fileName, resolvedCode, tabId }) {
  // Store the resolution in local storage keyed by file+tab
  const key = `resolution_${tabId}_${btoa(fileName || 'file').replace(/=/g, '')}`;
  await chrome.storage.local.set({
    [key]: {
      fileName,
      resolvedCode,
      resolvedAt: new Date().toISOString(),
      status: 'resolved'
    }
  });
  return { success: true, key };
}
