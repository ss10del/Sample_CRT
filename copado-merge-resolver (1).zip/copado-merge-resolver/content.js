// content.js — Copado AI Merge Resolver Content Script
(function () {
  'use strict';

  const EXT_ID = 'copado-ai-resolver';
  let panelInjected = false;
  let observer = null;

  // ─── Conflict Detection Selectors ────────────────────────────────────────────
  // Copado renders conflicts inside LWC components with these patterns
  const CONFLICT_SELECTORS = [
    '[data-component-id*="copado"]',
    '.copado-conflict',
    'copado-conflict-viewer',
    'copado-merge-panel',
    '[class*="conflictPanel"]',
    '[class*="conflict-panel"]',
    '[class*="mergeConflict"]',
    '.diff-viewer',
    '[data-conflict]',
    // Copado User Story merge page markers
    '[title*="Resolve Conflict"]',
    '[title*="Merge Conflict"]',
    'lightning-tab[label*="Conflict"]',
    'lightning-tab[label*="Merge"]',
    // Generic code diff containers
    '.CodeMirror',
    '.ace_editor',
    '[class*="diffEditor"]',
    '[class*="diff-editor"]'
  ];

  const CONFLICT_URL_PATTERNS = [
    /conflict/i,
    /merge/i,
    /user.?story/i,
    /copado/i,
    /gitconflict/i
  ];

  // ─── Bootstrap ────────────────────────────────────────────────────────────────
  function init() {
    if (document.readyState !== 'loading') {
      startWatching();
    } else {
      document.addEventListener('DOMContentLoaded', startWatching);
    }
  }

  function startWatching() {
    // Check immediately
    detectAndInject();

    // Watch for SPA navigation and dynamic content
    observer = new MutationObserver(debounce(() => {
      if (!panelInjected) detectAndInject();
      else syncPanelIfNeeded();
    }, 500));

    observer.observe(document.body, {
      childList: true,
      subtree: true,
      attributes: false
    });

    // Also watch for URL changes (SPA)
    let lastUrl = location.href;
    new MutationObserver(() => {
      if (location.href !== lastUrl) {
        lastUrl = location.href;
        panelInjected = false;
        removeExistingPanel();
        setTimeout(detectAndInject, 1000);
      }
    }).observe(document, { subtree: true, childList: true });
  }

  // ─── Detection Logic ──────────────────────────────────────────────────────────
  function detectAndInject() {
    const hasConflictInUrl = CONFLICT_URL_PATTERNS.some(p => p.test(location.href));
    const conflictNode = findConflictNode();

    if (!conflictNode && !hasConflictInUrl) return;

    // Look for conflict markers in text
    const bodyText = document.body.innerText || '';
    const hasConflictMarkers = /<<<<<<<|=======|>>>>>>>/.test(bodyText);
    const hasCopadoConflict = document.querySelector(
      '[class*="conflict"], [class*="Conflict"], [id*="conflict"], copado-merge-conflict-item, c-merge-conflict'
    );

    if (conflictNode || hasConflictMarkers || hasCopadoConflict) {
      setTimeout(() => injectPanel(conflictNode || hasCopadoConflict || document.body), 800);
    }
  }

  function findConflictNode() {
    for (const sel of CONFLICT_SELECTORS) {
      try {
        const el = document.querySelector(sel);
        if (el) return el;
      } catch {}
    }
    return null;
  }

  // ─── Panel Injection ──────────────────────────────────────────────────────────
  function injectPanel(anchor) {
    if (panelInjected || document.getElementById(EXT_ID + '-container')) return;
    panelInjected = true;

    const { baseCode, incomingCode, fileName, conflictBlocks } = extractConflictData();

    const container = document.createElement('div');
    container.id = EXT_ID + '-container';
    container.innerHTML = buildPanelHTML(baseCode, incomingCode, fileName, conflictBlocks);
    document.body.appendChild(container);

    setupPanelEvents(container, { baseCode, incomingCode, fileName, conflictBlocks });
    makeDraggable(container.querySelector(`#${EXT_ID}-panel`));

    // Animate in
    requestAnimationFrame(() => {
      const panel = container.querySelector(`#${EXT_ID}-panel`);
      panel.classList.add('cam-visible');
    });
  }

  function removeExistingPanel() {
    const existing = document.getElementById(EXT_ID + '-container');
    if (existing) existing.remove();
  }

  function syncPanelIfNeeded() {
    // Re-check if a new conflict loaded without navigation
    const panel = document.getElementById(EXT_ID + '-container');
    if (!panel) {
      panelInjected = false;
      detectAndInject();
    }
  }

  // ─── Conflict Data Extraction ─────────────────────────────────────────────────
  function extractConflictData() {
    let baseCode = '', incomingCode = '', fileName = 'Unknown File';
    const conflictBlocks = [];

    // Try to find file name from page
    const titleEl = document.querySelector(
      '[class*="fileName"], [class*="file-name"], [data-file], .title, h1, h2'
    );
    if (titleEl) fileName = titleEl.textContent.trim().replace(/\s+/g, ' ').substring(0, 100);

    // Extract from Copado's specific conflict panels
    const panels = document.querySelectorAll(
      '[class*="conflictPanel"], [class*="conflict-panel"], [class*="panel"], .CodeMirror, .ace_editor'
    );

    if (panels.length >= 2) {
      baseCode = extractTextFromPanel(panels[0]);
      incomingCode = extractTextFromPanel(panels[1]);
    } else {
      // Fallback: search all text for conflict markers
      const codeEls = document.querySelectorAll('pre, code, .CodeMirror-code, .ace_content');
      let combined = '';
      codeEls.forEach(el => { combined += el.textContent + '\n'; });
      const parsed = parseConflictMarkers(combined);
      baseCode = parsed.base;
      incomingCode = parsed.incoming;
    }

    // Parse out individual conflict blocks
    const fullText = baseCode + '\n' + incomingCode;
    const blockRegex = /<<<<<<< ?(.*?)\n([\s\S]*?)=======\n([\s\S]*?)>>>>>>> ?(.*?)(?:\n|$)/gm;
    let match;
    while ((match = blockRegex.exec(fullText)) !== null) {
      conflictBlocks.push({
        baseBranch: match[1].trim() || 'BASE',
        baseLines: match[2].trim(),
        incomingLines: match[3].trim(),
        incomingBranch: match[4].trim() || 'INCOMING'
      });
    }

    // If no code extracted, use placeholder demo data
    if (!baseCode && !incomingCode) {
      baseCode = getDemoBase();
      incomingCode = getDemoIncoming();
      fileName = 'AccountTrigger.trigger (Demo Mode)';
    }

    return { baseCode, incomingCode, fileName, conflictBlocks };
  }

  function extractTextFromPanel(el) {
    const cm = el.querySelector('.CodeMirror-code');
    if (cm) return Array.from(cm.querySelectorAll('.CodeMirror-line')).map(l => l.textContent).join('\n');
    const ace = el.querySelector('.ace_content');
    if (ace) return ace.textContent;
    return el.textContent || el.innerText || '';
  }

  function parseConflictMarkers(text) {
    const lines = text.split('\n');
    let base = [], incoming = [], mode = 'outside';
    for (const line of lines) {
      if (line.startsWith('<<<<<<<')) { mode = 'base'; continue; }
      if (line.startsWith('=======')) { mode = 'incoming'; continue; }
      if (line.startsWith('>>>>>>>')) { mode = 'outside'; continue; }
      if (mode === 'base') base.push(line);
      else if (mode === 'incoming') incoming.push(line);
    }
    return { base: base.join('\n'), incoming: incoming.join('\n') };
  }

  // ─── Panel HTML Builder ────────────────────────────────────────────────────────
  function buildPanelHTML(baseCode, incomingCode, fileName, conflictBlocks) {
    return `
<div id="${EXT_ID}-backdrop"></div>
<div id="${EXT_ID}-panel" role="dialog" aria-label="AI Merge Conflict Resolver">
  <!-- Header -->
  <div class="cam-header" id="${EXT_ID}-drag-handle">
    <div class="cam-header-left">
      <div class="cam-logo">
        <svg width="20" height="20" viewBox="0 0 20 20" fill="none"><path d="M10 2L3 6v8l7 4 7-4V6L10 2z" stroke="#00d4aa" stroke-width="1.5" fill="none"/><circle cx="10" cy="10" r="2.5" fill="#00d4aa"/></svg>
      </div>
      <div class="cam-title-block">
        <span class="cam-title">AI Merge Resolver</span>
        <span class="cam-subtitle" id="${EXT_ID}-filename">${escapeHtml(fileName)}</span>
      </div>
      <div class="cam-badge">${conflictBlocks.length || '?'} conflict${conflictBlocks.length !== 1 ? 's' : ''}</div>
    </div>
    <div class="cam-header-right">
      <button class="cam-icon-btn" id="${EXT_ID}-minimize" title="Minimize">
        <svg width="14" height="14" viewBox="0 0 14 14"><line x1="2" y1="7" x2="12" y2="7" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>
      </button>
      <button class="cam-icon-btn" id="${EXT_ID}-close" title="Close">
        <svg width="14" height="14" viewBox="0 0 14 14"><line x1="2" y1="2" x2="12" y2="12" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/><line x1="12" y1="2" x2="2" y2="12" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>
      </button>
    </div>
  </div>

  <!-- Status Bar -->
  <div class="cam-status-bar" id="${EXT_ID}-status">
    <span class="cam-status-dot cam-dot-idle"></span>
    <span id="${EXT_ID}-status-text">Ready — Click "Resolve with AI" to analyze conflicts</span>
  </div>

  <!-- Three-Panel Diff View -->
  <div class="cam-panels-wrapper">
    <div class="cam-panels" id="${EXT_ID}-panels">
      <!-- Panel 1: Base -->
      <div class="cam-panel cam-panel-base">
        <div class="cam-panel-header">
          <span class="cam-panel-dot cam-dot-red"></span>
          <span class="cam-panel-label">BASE / CURRENT</span>
          <span class="cam-panel-branch" id="${EXT_ID}-base-branch">${escapeHtml(conflictBlocks[0]?.baseBranch || 'current branch')}</span>
        </div>
        <div class="cam-code-view" id="${EXT_ID}-base-code">
          ${renderCodeLines(baseCode, 'base')}
        </div>
      </div>

      <!-- Panel 2: Incoming -->
      <div class="cam-panel cam-panel-incoming">
        <div class="cam-panel-header">
          <span class="cam-panel-dot cam-dot-yellow"></span>
          <span class="cam-panel-label">INCOMING CHANGES</span>
          <span class="cam-panel-branch" id="${EXT_ID}-incoming-branch">${escapeHtml(conflictBlocks[0]?.incomingBranch || 'incoming branch')}</span>
        </div>
        <div class="cam-code-view" id="${EXT_ID}-incoming-code">
          ${renderCodeLines(incomingCode, 'incoming')}
        </div>
      </div>

      <!-- Panel 3: AI Resolved -->
      <div class="cam-panel cam-panel-ai cam-panel-ai-loading" id="${EXT_ID}-ai-panel">
        <div class="cam-panel-header">
          <span class="cam-panel-dot cam-dot-green"></span>
          <span class="cam-panel-label">AI RESOLVED</span>
          <span class="cam-panel-branch">Copilot AI Suggestion</span>
          <div class="cam-panel-actions">
            <button class="cam-btn-sm" id="${EXT_ID}-toggle-edit" disabled title="Toggle Edit Mode">
              <svg width="12" height="12" viewBox="0 0 12 12"><path d="M8.5 1.5l2 2L4 10H2V8L8.5 1.5z" stroke="currentColor" stroke-width="1.2" fill="none"/></svg>
              Edit
            </button>
            <button class="cam-btn-sm cam-btn-success" id="${EXT_ID}-save-btn" disabled title="Accept and Save Resolution">
              <svg width="12" height="12" viewBox="0 0 12 12"><polyline points="2,6 5,9 10,3" stroke="currentColor" stroke-width="1.5" fill="none" stroke-linecap="round"/></svg>
              Accept
            </button>
          </div>
        </div>
        <div class="cam-code-view cam-ai-code-view" id="${EXT_ID}-ai-code">
          <div class="cam-placeholder" id="${EXT_ID}-placeholder">
            <div class="cam-placeholder-icon">
              <svg width="40" height="40" viewBox="0 0 40 40" fill="none"><path d="M20 5L5 12.5v15L20 35l15-7.5v-15L20 5z" stroke="#00d4aa" stroke-width="1.5" fill="none" opacity="0.5"/><circle cx="20" cy="20" r="5" fill="#00d4aa" opacity="0.3"/><path d="M15 20h10M20 15v10" stroke="#00d4aa" stroke-width="1.5" stroke-linecap="round"/></svg>
            </div>
            <p class="cam-placeholder-text">AI resolution will appear here</p>
            <p class="cam-placeholder-sub">Each changed line includes impact analysis</p>
          </div>
        </div>
        <div class="cam-edit-area" id="${EXT_ID}-edit-area" style="display:none">
          <textarea id="${EXT_ID}-editor" spellcheck="false" placeholder="Edit resolved code here..."></textarea>
        </div>
      </div>
    </div>
  </div>

  <!-- AI Summary Panel -->
  <div class="cam-summary" id="${EXT_ID}-summary" style="display:none">
    <div class="cam-summary-header">
      <svg width="14" height="14" viewBox="0 0 14 14"><circle cx="7" cy="7" r="6" stroke="#00d4aa" stroke-width="1.2" fill="none"/><path d="M7 6v4M7 4.5v.5" stroke="#00d4aa" stroke-width="1.2" stroke-linecap="round"/></svg>
      <span>AI Analysis Summary</span>
    </div>
    <div class="cam-summary-content" id="${EXT_ID}-summary-content"></div>
    <div class="cam-summary-meta" id="${EXT_ID}-summary-meta"></div>
  </div>

  <!-- Action Footer -->
  <div class="cam-footer">
    <div class="cam-footer-left">
      <button class="cam-btn cam-btn-primary" id="${EXT_ID}-resolve-btn">
        <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M7 1L1 4v6l6 3 6-3V4L7 1z" stroke="currentColor" stroke-width="1.2"/><circle cx="7" cy="7" r="2" fill="currentColor"/></svg>
        Resolve with AI
      </button>
      <button class="cam-btn cam-btn-ghost" id="${EXT_ID}-refresh-btn">
        <svg width="14" height="14" viewBox="0 0 14 14"><path d="M12 7A5 5 0 113 4.5M3 2v3h3" stroke="currentColor" stroke-width="1.2" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>
        Re-scan
      </button>
    </div>
    <div class="cam-footer-right">
      <span class="cam-footer-hint" id="${EXT_ID}-footer-hint">Powered by Claude AI</span>
    </div>
  </div>
</div>`;
  }

  // ─── Code Rendering ────────────────────────────────────────────────────────────
  function renderCodeLines(code, type) {
    if (!code || !code.trim()) return `<div class="cam-empty-code">No code extracted</div>`;
    const lines = code.split('\n');
    let html = '<div class="cam-lines">';
    lines.forEach((line, i) => {
      const isConflictStart = line.startsWith('<<<<<<<');
      const isConflictSep = line.startsWith('=======');
      const isConflictEnd = line.startsWith('>>>>>>>');
      const isMarker = isConflictStart || isConflictSep || isConflictEnd;
      const cls = isMarker ? 'cam-line cam-line-marker' :
                  (type === 'base' ? 'cam-line cam-line-base-hl' : 'cam-line cam-line-incoming-hl');
      html += `<div class="${cls}" data-line="${i + 1}">
        <span class="cam-ln">${i + 1}</span>
        <span class="cam-lc">${escapeHtml(line) || '&nbsp;'}</span>
      </div>`;
    });
    return html + '</div>';
  }

  function renderAICodeLines(lineAnalysis, resolvedCode) {
    if (!lineAnalysis || !lineAnalysis.length) {
      const lines = resolvedCode.split('\n');
      let html = '<div class="cam-lines">';
      lines.forEach((line, i) => {
        html += `<div class="cam-line" data-line="${i+1}">
          <span class="cam-ln">${i+1}</span>
          <span class="cam-lc">${escapeHtml(line) || '&nbsp;'}</span>
        </div>`;
      });
      return html + '</div>';
    }

    let html = '<div class="cam-lines">';
    lineAnalysis.forEach((la, i) => {
      const isChanged = la.changeType !== 'unchanged';
      const typeClass = {
        'added': 'cam-line-added',
        'removed': 'cam-line-removed',
        'modified': 'cam-line-modified',
        'conflict-resolved': 'cam-line-resolved',
        'ai-generated': 'cam-line-ai',
        'unchanged': ''
      }[la.changeType] || '';

      const confIcon = la.confidence === 'high' ? '●' : la.confidence === 'medium' ? '◐' : '○';
      const confClass = `cam-conf-${la.confidence || 'high'}`;

      html += `<div class="cam-line ${typeClass} ${isChanged ? 'cam-line-interactive' : ''}" 
               data-line="${la.lineNumber}" 
               data-impact="${escapeHtml(la.impact || '')}"
               data-source="${la.source || ''}"
               data-confidence="${la.confidence || 'high'}">
        <span class="cam-ln">${la.lineNumber}</span>
        ${isChanged ? `<span class="cam-conf ${confClass}" title="Confidence: ${la.confidence}">${confIcon}</span>` : '<span class="cam-conf-empty"></span>'}
        <span class="cam-lc">${escapeHtml(la.code || '') || '&nbsp;'}</span>
        ${isChanged ? `<div class="cam-impact-tooltip">
          <div class="cam-impact-header">
            <span class="cam-impact-type">${la.changeType}</span>
            <span class="cam-impact-source">from: ${la.source || 'ai'}</span>
          </div>
          <p class="cam-impact-text">${escapeHtml(la.impact || 'No analysis available')}</p>
        </div>` : ''}
      </div>`;
    });
    return html + '</div>';
  }

  // ─── Event Handlers ────────────────────────────────────────────────────────────
  function setupPanelEvents(container, conflictData) {
    const panel = container.querySelector(`#${EXT_ID}-panel`);
    const resolveBtn = container.querySelector(`#${EXT_ID}-resolve-btn`);
    const closeBtn = container.querySelector(`#${EXT_ID}-close`);
    const minimizeBtn = container.querySelector(`#${EXT_ID}-minimize`);
    const refreshBtn = container.querySelector(`#${EXT_ID}-refresh-btn`);
    const editBtn = container.querySelector(`#${EXT_ID}-toggle-edit`);
    const saveBtn = container.querySelector(`#${EXT_ID}-save-btn`);

    closeBtn.addEventListener('click', () => {
      panel.classList.remove('cam-visible');
      setTimeout(() => { container.remove(); panelInjected = false; }, 300);
    });

    minimizeBtn.addEventListener('click', () => {
      panel.classList.toggle('cam-minimized');
    });

    refreshBtn.addEventListener('click', () => {
      const fresh = extractConflictData();
      conflictData = fresh;
      updateCodePanels(container, fresh);
      setStatus(container, 'idle', 'Page re-scanned. Click "Resolve with AI" to analyze.');
    });

    resolveBtn.addEventListener('click', () => runAIResolution(container, conflictData));

    editBtn.addEventListener('click', () => toggleEditMode(container));

    saveBtn.addEventListener('click', () => saveResolution(container, conflictData));

    // Sync scroll across panels
    const panels = container.querySelectorAll('.cam-code-view');
    panels.forEach(p => {
      p.addEventListener('scroll', () => {
        panels.forEach(op => {
          if (op !== p) op.scrollTop = p.scrollTop;
        });
      });
    });
  }

  async function runAIResolution(container, conflictData) {
    setStatus(container, 'loading', 'Analyzing conflict with AI...');
    setResolveBtn(container, true);

    const aiPanel = container.querySelector(`#${EXT_ID}-ai-panel`);
    const placeholder = container.querySelector(`#${EXT_ID}-placeholder`);
    aiPanel.classList.add('cam-panel-ai-loading');

    placeholder.innerHTML = `
      <div class="cam-spinner"></div>
      <p class="cam-placeholder-text">AI is resolving conflicts...</p>
      <p class="cam-placeholder-sub">Analyzing ${conflictData.conflictBlocks.length || 'all'} conflict blocks</p>
    `;

    try {
      const result = await new Promise((resolve, reject) => {
        chrome.runtime.sendMessage({
          type: 'RESOLVE_CONFLICT',
          payload: conflictData
        }, response => {
          if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
          else if (response?.error) reject(new Error(response.error));
          else resolve(response);
        });
      });

      displayAIResolution(container, result, conflictData);
      setStatus(container, 'success', `✓ Resolved ${result.conflictsResolved || '?'} conflicts — Risk: ${result.riskLevel || 'unknown'}`);
    } catch (err) {
      setStatus(container, 'error', `Error: ${err.message}`);
      placeholder.innerHTML = `
        <div class="cam-error-icon">⚠</div>
        <p class="cam-placeholder-text">Resolution failed</p>
        <p class="cam-placeholder-sub">${escapeHtml(err.message)}</p>
        ${err.message.includes('API key') ? '<a class="cam-link" id="cam-open-settings">Open Settings →</a>' : ''}
      `;
      const settingsLink = container.querySelector('#cam-open-settings');
      if (settingsLink) settingsLink.addEventListener('click', () => chrome.runtime.sendMessage({ type: 'OPEN_POPUP' }));
    } finally {
      setResolveBtn(container, false);
      aiPanel.classList.remove('cam-panel-ai-loading');
    }
  }

  function displayAIResolution(container, result, conflictData) {
    const aiCodeView = container.querySelector(`#${EXT_ID}-ai-code`);
    aiCodeView.innerHTML = renderAICodeLines(result.lineAnalysis, result.resolvedCode || '');

    // Store resolved code
    container._resolvedCode = result.resolvedCode;

    // Editor sync
    const editor = container.querySelector(`#${EXT_ID}-editor`);
    if (editor) editor.value = result.resolvedCode || '';

    // Enable buttons
    container.querySelector(`#${EXT_ID}-toggle-edit`).disabled = false;
    container.querySelector(`#${EXT_ID}-save-btn`).disabled = false;

    // Show summary
    const summary = container.querySelector(`#${EXT_ID}-summary`);
    const summaryContent = container.querySelector(`#${EXT_ID}-summary-content`);
    const summaryMeta = container.querySelector(`#${EXT_ID}-summary-meta`);

    if (result.summary) {
      summary.style.display = 'block';
      summaryContent.textContent = result.summary;
      summaryMeta.innerHTML = `
        <span class="cam-meta-tag cam-risk-${result.riskLevel}">${result.riskLevel || 'unknown'} risk</span>
        <span class="cam-meta-tag">${result.conflictsResolved || 0} resolved</span>
        ${result.deploymentNotes ? `<span class="cam-meta-note">${escapeHtml(result.deploymentNotes)}</span>` : ''}
      `;
    }
  }

  function toggleEditMode(container) {
    const editBtn = container.querySelector(`#${EXT_ID}-toggle-edit`);
    const aiCodeView = container.querySelector(`#${EXT_ID}-ai-code`);
    const editArea = container.querySelector(`#${EXT_ID}-edit-area`);
    const editor = container.querySelector(`#${EXT_ID}-editor`);
    const isEdit = editArea.style.display !== 'none';

    if (isEdit) {
      // Save edits back to display
      container._resolvedCode = editor.value;
      aiCodeView.style.display = '';
      editArea.style.display = 'none';
      editBtn.classList.remove('cam-btn-active');
      editBtn.textContent = '✎ Edit';
    } else {
      editor.value = container._resolvedCode || '';
      aiCodeView.style.display = 'none';
      editArea.style.display = '';
      editBtn.classList.add('cam-btn-active');
      editBtn.textContent = '✓ Done';
      editor.focus();
    }
  }

  async function saveResolution(container, conflictData) {
    const resolvedCode = container._resolvedCode;
    if (!resolvedCode) return;

    const saveBtn = container.querySelector(`#${EXT_ID}-save-btn`);
    saveBtn.disabled = true;
    saveBtn.textContent = 'Saving...';
    setStatus(container, 'loading', 'Saving resolution to Copado...');

    try {
      // Attempt to write back to Copado's editor
      const written = writeResolvedToPage(resolvedCode);

      // Also persist in extension storage
      await new Promise((resolve, reject) => {
        chrome.runtime.sendMessage({
          type: 'SAVE_RESOLUTION',
          payload: {
            fileName: conflictData.fileName,
            resolvedCode,
            tabId: 'current'
          }
        }, response => {
          if (response?.error) reject(new Error(response.error));
          else resolve(response);
        });
      });

      setStatus(container, 'success', written
        ? '✓ Resolution saved and applied to Copado editor'
        : '✓ Resolution saved — Copy code to Copado editor manually');

      saveBtn.textContent = '✓ Accepted';
      saveBtn.classList.add('cam-btn-accepted');

      if (!written) showCopyFallback(container, resolvedCode);
    } catch (err) {
      setStatus(container, 'error', `Save failed: ${err.message}`);
      saveBtn.disabled = false;
      saveBtn.textContent = '✓ Accept';
    }
  }

  function writeResolvedToPage(resolvedCode) {
    // Attempt to write into Copado's editor (CodeMirror, ACE, or textarea)
    const cm = document.querySelector('.CodeMirror');
    if (cm?.CodeMirror) {
      cm.CodeMirror.setValue(resolvedCode);
      return true;
    }

    const ace = document.querySelector('.ace_editor');
    if (ace && window.ace) {
      const editor = window.ace.edit(ace);
      editor.setValue(resolvedCode, -1);
      return true;
    }

    // Try native input/textarea
    const textarea = document.querySelector(
      'textarea[class*="editor"], textarea[class*="code"], textarea[class*="conflict"]'
    );
    if (textarea) {
      const nativeInputValueSetter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value').set;
      nativeInputValueSetter.call(textarea, resolvedCode);
      textarea.dispatchEvent(new Event('input', { bubbles: true }));
      return true;
    }

    // LWC / React controlled inputs
    const inputs = document.querySelectorAll('input[class*="code"], [contenteditable="true"]');
    for (const inp of inputs) {
      if (inp.tagName === 'INPUT') {
        const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
        setter.call(inp, resolvedCode);
        inp.dispatchEvent(new Event('input', { bubbles: true }));
        return true;
      } else {
        inp.textContent = resolvedCode;
        inp.dispatchEvent(new Event('input', { bubbles: true }));
        return true;
      }
    }

    return false;
  }

  function showCopyFallback(container, code) {
    const footer = container.querySelector('.cam-footer-hint');
    footer.innerHTML = `<button class="cam-copy-btn" id="${EXT_ID}-copy-code">📋 Copy Resolved Code</button>`;
    container.querySelector(`#${EXT_ID}-copy-code`).addEventListener('click', () => {
      navigator.clipboard.writeText(code).then(() => {
        footer.textContent = '✓ Copied to clipboard!';
      });
    });
  }

  function updateCodePanels(container, data) {
    container.querySelector(`#${EXT_ID}-base-code`).innerHTML = renderCodeLines(data.baseCode, 'base');
    container.querySelector(`#${EXT_ID}-incoming-code`).innerHTML = renderCodeLines(data.incomingCode, 'incoming');
    container.querySelector(`#${EXT_ID}-filename`).textContent = data.fileName;
    const badgeEl = container.querySelector('.cam-badge');
    if (badgeEl) badgeEl.textContent = `${data.conflictBlocks.length || '?'} conflict${data.conflictBlocks.length !== 1 ? 's' : ''}`;
  }

  // ─── Status Helpers ────────────────────────────────────────────────────────────
  function setStatus(container, state, text) {
    const bar = container.querySelector(`#${EXT_ID}-status`);
    const dot = bar.querySelector('.cam-status-dot');
    const txt = bar.querySelector(`#${EXT_ID}-status-text`);
    dot.className = `cam-status-dot cam-dot-${state}`;
    txt.textContent = text;
  }

  function setResolveBtn(container, loading) {
    const btn = container.querySelector(`#${EXT_ID}-resolve-btn`);
    btn.disabled = loading;
    btn.innerHTML = loading
      ? '<span class="cam-spin">⟳</span> Resolving...'
      : `<svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M7 1L1 4v6l6 3 6-3V4L7 1z" stroke="currentColor" stroke-width="1.2"/><circle cx="7" cy="7" r="2" fill="currentColor"/></svg> Resolve with AI`;
  }

  // ─── Drag Logic ────────────────────────────────────────────────────────────────
  function makeDraggable(panel) {
    const handle = panel.querySelector(`#${EXT_ID}-drag-handle`);
    let isDragging = false, startX, startY, origLeft, origTop;

    handle.addEventListener('mousedown', (e) => {
      if (e.target.closest('button')) return;
      isDragging = true;
      startX = e.clientX;
      startY = e.clientY;
      const rect = panel.getBoundingClientRect();
      origLeft = rect.left;
      origTop = rect.top;
      panel.style.transition = 'none';
      document.body.style.userSelect = 'none';
    });

    document.addEventListener('mousemove', (e) => {
      if (!isDragging) return;
      const dx = e.clientX - startX;
      const dy = e.clientY - startY;
      panel.style.left = `${origLeft + dx}px`;
      panel.style.top = `${origTop + dy}px`;
      panel.style.right = 'auto';
      panel.style.bottom = 'auto';
    });

    document.addEventListener('mouseup', () => {
      if (isDragging) {
        isDragging = false;
        panel.style.transition = '';
        document.body.style.userSelect = '';
      }
    });
  }

  // ─── Utilities ─────────────────────────────────────────────────────────────────
  function escapeHtml(str) {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function debounce(fn, ms) {
    let timer;
    return (...args) => { clearTimeout(timer); timer = setTimeout(() => fn(...args), ms); };
  }

  // ─── Demo Data (when no conflict found on page) ────────────────────────────────
  function getDemoBase() {
    return `trigger AccountTrigger on Account (before insert, before update) {
    if (Trigger.isBefore && Trigger.isInsert) {
        for (Account acc : Trigger.new) {
<<<<<<< current-branch
            if (acc.Phone == null) {
                acc.Phone = '000-000-0000';
            }
=======
>>>>>>> incoming-branch
            AccountHandler.validateAccount(acc);
        }
    }
}`;
  }

  function getDemoIncoming() {
    return `trigger AccountTrigger on Account (before insert, before update) {
    if (Trigger.isBefore && Trigger.isInsert) {
        for (Account acc : Trigger.new) {
<<<<<<< current-branch
=======
            if (acc.BillingCountry == null) {
                acc.BillingCountry = 'US';
            }
>>>>>>> incoming-branch
            AccountHandler.validateAccount(acc);
        }
    }
}`;
  }

  // ─── Fire ─────────────────────────────────────────────────────────────────────
  init();

})();
